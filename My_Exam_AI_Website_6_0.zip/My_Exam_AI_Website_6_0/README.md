# My Exam AI Website 6.0

이 버전은 **APK가 아니라 먼저 둘이 함께 접속해서 쓰는 웹사이트**를 목표로 만든 배포판입니다.

## 사용자 구조

```text
하나의 사이트 / 하나의 OpenAI API 결제 계정
├─ 내 프로필 (소유자)
│  ├─ 경제학
│  ├─ 영어
│  └─ 기타 과목...
└─ 사용자 2
   ├─ 그 사람의 과목
   └─ 그 사람의 학습기록
```

### 중요한 격리 방식
- 브라우저에서 프로필 PIN을 확인하면 서버가 로그인 세션을 발급합니다.
- `/api/p/<프로필ID>/...` 요청은 현재 로그인 세션의 프로필 ID와 일치해야만 처리됩니다.
- 과목 검색은 항상 `profile_id + course_id` 범위에서만 이뤄집니다.
- 다른 과목 PDF, 오답, AI 대화가 현재 과목 프롬프트에 전달되지 않습니다.

## 처음 사용
1. 사이트에서 **내 프로필** 선택.
2. 사용자 설정에서 내 PIN을 설정.
3. 소유자 화면에서 두 번째 사용자 이름 + PIN을 생성.
4. 각자 자기 프로필로 들어가 과목 생성.
5. 각 과목에 PDF 업로드 후 `자동 분석`.

## Railway에 사이트로 배포
이 프로젝트는 Docker + `railway.toml`이 포함되어 있습니다.

Railway 설정:
- Volume mount path: `/data`
- Variables:
  - `OPENAI_API_KEY`
  - `OPENAI_MODEL=gpt-5.6`
  - `OPENAI_VISION_MODEL=gpt-5.6`
  - `SESSION_SECRET=<긴 랜덤 문자열>`
  - `COOKIE_HTTPS_ONLY=1`
  - `DATA_ROOT=/data`
  - `APP_ACCESS_CODE=<선택>`

배포 후 Public Networking에서 도메인을 생성하면
`https://xxxxx.up.railway.app` 같은 웹사이트 주소로 둘이 접속할 수 있습니다.

## 로컬 실행
```bash
pip install -r requirements.txt
uvicorn server:app --host 0.0.0.0 --port 8000
```

브라우저: `http://127.0.0.1:8000`

## AI 비용
ChatGPT Plus 구독과 OpenAI API는 별도입니다.
둘이 사이트를 사용하면 이 사이트에 연결한 하나의 `OPENAI_API_KEY` 사용량으로 합산됩니다.

## 다음 단계
사이트 주소가 실제로 생긴 뒤에는 그 주소를 그대로 Android 앱(PWA/Capacitor)로 감싸 APK를 만들면 됩니다.
