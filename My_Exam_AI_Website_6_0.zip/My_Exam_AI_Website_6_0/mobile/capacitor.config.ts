import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.myexamai.app',
  appName: 'My Exam AI',
  webDir: 'www',
  server: {
    url: 'https://YOUR-DEPLOYED-SERVER.example.com',
    cleartext: false
  }
};
export default config;
