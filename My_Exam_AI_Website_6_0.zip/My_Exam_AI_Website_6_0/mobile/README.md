# Android wrapper

1. 먼저 My Exam AI 서버를 HTTPS 주소에 배포합니다.
2. `capacitor.config.ts`의 `server.url`을 실제 서버 주소로 바꿉니다.
3. Node.js 설치 후:
   ```bash
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
4. Android Studio에서 Build > Generate App Bundles or APKs > Generate APKs.

이 폴더는 APK 자체가 아니라 Android Studio/Capacitor 빌드용 준비물입니다.
